# Data types of Variables

fullname = "John Doe"
email = "john.doe@gmail.com"
age = 30
address = "NYC"
isFresher = True

print("Assignment 2")
print(type(fullname))
print(type(email))
print(type(age))
print(type(address))
print(type(isFresher))
