# Convert decimal value to non-decimal

salary = float(input("Enter the amount"))

print("Assignment 3")
print(int(salary))