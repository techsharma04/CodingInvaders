videoTuple = ("Tuple in Python", [13.0, 134.5, 89.3, 98.4])

dictVideo = videoTuple[0]
dictTime = videoTuple[1]

videoDict = {dictVideo: dictTime}

print(videoDict)
