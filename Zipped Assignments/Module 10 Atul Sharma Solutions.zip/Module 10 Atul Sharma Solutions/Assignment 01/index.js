function mainFunc(str){
    console.log("Hello there");
}
mainFunc();