let arr = [2, 3, 5, 4, 8, 6, 9];

let res = arr.map((e) => {
    return Math.pow(e,2); 
})
console.log(res);