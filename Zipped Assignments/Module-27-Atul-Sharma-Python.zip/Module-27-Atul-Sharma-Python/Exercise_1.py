noOfPlayTimes = [10.5, 45.67, 32.3, 9.28, 7.3, 55.67, 123.4, 11.2, 6.25, 3.9]

# Find the longest running video
longest_video = max(noOfPlayTimes)

print(f"The longest running video has a play time of {longest_video} minutes.")
