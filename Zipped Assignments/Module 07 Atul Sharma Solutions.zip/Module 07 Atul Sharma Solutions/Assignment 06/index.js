const goods = [

    ["Apples", "fruit"],

    ["Milk 3.2%", "dairy products"],

    ["Potato", "vegetables"],

    ["Brinjal", "vegetables"],

    ["Mango", "fruit"],

    ["Cheese", "dairy products"]

]

//create 3 arrays to store 3 category items
let fruitBasket = [];
let dairyBasket = [];
let vegBasket = [];


for (let good of goods) {
    if (good[1] === "fruit") {
        fruitBasket.push(good[0]);
    } else if (good[1] === "dairy products") {
        dairyBasket.push(good[0]);
    } else if (good[1] === "vegetables") {
        vegBasket.push(good[0]);
    }
}


//fruit category
for (let i = 0; i < fruitBasket.length; i++) {
    if (i === 0) { console.log(`FRUIT`) };
    console.log(fruitBasket[i]);
}
//dairy category
for (let j = 0; j < dairyBasket.length; j++) {
    if (j === 0) { console.log(`\nDAIRY PRODUCTS`) };
    console.log(dairyBasket[j]);
}
//vegetables category
for (let k = 0; k < vegBasket.length; k++) {
    if (k === 0) { console.log(`\nVEGETABLES`) };
    console.log(vegBasket[k]);
}
