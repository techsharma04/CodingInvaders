function redirect() {
    location.href = "../";
}