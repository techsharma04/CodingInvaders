let promo = prompt("Enter promo code here...!!!")
while(promo !== "HOLIDAYS22"){
    alert("Incorrect");
    promo = prompt("Enter promo code here...!!!")
}
alert("10% discount has been applied");
