let password = prompt("Please enter password here..!!!")
if(password.length >= 8){
    alert("acceptable");
} else{
    alert("not acceptable");
}