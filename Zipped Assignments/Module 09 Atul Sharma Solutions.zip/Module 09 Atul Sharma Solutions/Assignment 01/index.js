let obj = {
    name: "Vishal",
    class: "X",
    seatNo: 987
}
console.log(Object.keys(obj).join(","));
