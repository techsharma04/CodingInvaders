function printMsg(){
    console.log("I want to become a full stack developer");
}

printMsg();