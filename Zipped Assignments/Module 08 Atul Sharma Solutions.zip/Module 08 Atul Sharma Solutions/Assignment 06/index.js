function power(x, y){
    return Math.pow(x, y);
}

let output = power(2, 3);
console.log(output);